"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-01-31"
-------------------------------------------------------
"""

from utilities import queue_to_array, priority_queue_test
from Queue_array import Queue
a = Queue()
target = []

a = [1,3,4,5]


priority_queue_test(a)


for i in target:
    print(i)
    