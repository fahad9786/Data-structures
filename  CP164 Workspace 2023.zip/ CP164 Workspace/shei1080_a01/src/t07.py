"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-01-19"
-------------------------------------------------------
"""


from functions import matrixes_multiply


a = [[1,2,3],
    [4,5,6]]


b = [[7,8],
         [9,10],
         [11,12]]
print(matrixes_multiply(a, b))
