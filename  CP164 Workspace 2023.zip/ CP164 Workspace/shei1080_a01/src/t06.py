"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
Section: CP164 B
__updated__ = "2023-01-13"
-------------------------------------------------------
"""

from functions import matrix_transpose

a = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]

print(matrix_transpose(a))