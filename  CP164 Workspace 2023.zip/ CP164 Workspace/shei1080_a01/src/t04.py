"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
Section: CP164 B
__updated__ = "2023-01-13"
-------------------------------------------------------
"""

from functions import is_leap_year
year = 1996
print(is_leap_year(year))