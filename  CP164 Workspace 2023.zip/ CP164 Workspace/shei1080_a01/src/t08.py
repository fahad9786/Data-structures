"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-01-18"
-------------------------------------------------------
"""

from functions import pig_latin

word = "Bob"
print(pig_latin(word))