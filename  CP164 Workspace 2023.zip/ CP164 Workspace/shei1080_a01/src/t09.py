"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""


from functions import shift

string = "David"
n = 1
print(shift(string, n))