"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
Section: CP164 B
__updated__ = "2023-01-13"
-------------------------------------------------------
"""
from functions import find_subs

String = "It was a really, really, big assignment."
Sub =  "real"

print(find_subs(String, Sub))