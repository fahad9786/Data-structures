"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-02-07"
-------------------------------------------------------
"""

from Movie_utilities import Movie

#key = Movie('Juno', 2007, None, None, None)
#print(key)

from utilities import array_to_list, list_test
from List_array import List
source = [1,2,3,4,5]

print(list_test(source))