"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-02-04"
-------------------------------------------------------
"""


from functions import postfix
string = "4 5.2 + "
print(postfix(string))
