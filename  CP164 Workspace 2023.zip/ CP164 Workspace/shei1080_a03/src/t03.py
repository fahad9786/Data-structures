"""w
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-02-03"
-------------------------------------------------------
"""


from Stack_array import Stack
from functions import is_palindrome_stack


string = "racecar"

print(is_palindrome_stack("hello"))
    
print(is_palindrome_stack("A man, a plan, a canal, Panama!"))

print(is_palindrome_stack("Otto"))


