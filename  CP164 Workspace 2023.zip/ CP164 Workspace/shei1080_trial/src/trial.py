"""
-------------------------------------------------------
Midterm Trial
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2022-10-19"
-------------------------------------------------------
"""
print("Congratulations, you imported this project correctly.")
