"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-02-14"
-------------------------------------------------------
"""

from functions import vowel_count

s = "BCDaFeGiHoJuXYZ"
count = vowel_count(s)
print(count)

