"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-02-14"
-------------------------------------------------------
"""

from functions import to_power

ans = to_power(-2, -2)
print(ans)