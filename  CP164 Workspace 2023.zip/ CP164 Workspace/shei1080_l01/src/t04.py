"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Fahad Sheikh
ID:      169031080
Email:   shei1080@mylaurier.ca
__updated__ = "2023-01-18"
-------------------------------------------------------
"""

from Movie import Movie
print(Movie.genres_menu())



